import { IsBoolean, IsDate, IsOptional, IsString } from 'class-validator';

export class TaskDto {
  @IsString()
  id: string;

  @IsString()
  title: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsBoolean()
  completed: boolean;

  @IsDate()
  createDate: Date;

  @IsOptional()
  @IsDate()
  completedDate?: Date;
}
