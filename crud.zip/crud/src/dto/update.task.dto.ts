import { IsBoolean, IsDate, IsOptional, IsString } from 'class-validator';

export class UpdateTaskDto {

  @IsString()
  title: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsBoolean()
  completed: boolean;

  @IsDate()
  createDate: Date;

  @IsOptional()
  @IsDate()
  completedDate?: Date;
}
