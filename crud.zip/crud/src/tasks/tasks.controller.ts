import { Controller, Get, Post, Put, Body, Param, Delete } from '@nestjs/common';
import { TasksService } from './tasks.service';
import { TaskDto } from '../dto/create.task.dto';
import { UpdateTaskDto } from '../dto/update.task.dto';

@Controller('tasks')
export class TasksController {
    constructor(private readonly tasksService: TasksService) {}

    @Post()
    async addTask(@Body() taskBody: TaskDto ): Promise<object> {
        console.log(taskBody)
        return this.tasksService.addTask(taskBody);
    }
    @Put(':id')
    async updateTask(@Body() updateTaskBody: UpdateTaskDto, @Param('id') id: string ): Promise<object> {
        return this.tasksService.updateTask(updateTaskBody,id);
    }
    @Get(':id')
    async getTask(@Param('id') id: string): Promise<object> {
      return this.tasksService.getTask(id);
    }
    @Get()
    async getTaskList(): Promise<object> {
      return this.tasksService.getTasks();
    }
    @Delete(':id')
    async deleteTask(@Param('id') id: string): Promise<object> {
      return this.tasksService.deleteTask(id);
    }
}
