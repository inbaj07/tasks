import { Test, TestingModule } from '@nestjs/testing';
import { TasksController } from './tasks.controller';
import { TasksService } from './tasks.service';
import { TaskDto } from '../dto/create.task.dto';
import { UpdateTaskDto } from '../dto/update.task.dto';

describe('TasksController', () => {
  let tasksController: TasksController;
  let tasksService: TasksService;

  const mockTasksService = {
    addTask: jest.fn(),
    updateTask: jest.fn(),
    getTask: jest.fn(),
    getTasks: jest.fn(),
    deleteTask: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TasksController],
      providers: [
        {
          provide: TasksService,
          useValue: mockTasksService,
        },
      ],
    }).compile();

    tasksController = module.get<TasksController>(TasksController);
    tasksService = module.get<TasksService>(TasksService);
  });

  it('should be defined', () => {
    expect(tasksController).toBeDefined();
  });

  describe('addTask', () => {
    it('should call TasksService.addTask and return its result', async () => {
      const taskBody: TaskDto = {
        title: 'Test Task', 
        description: 'Test Description',
        id: '1',
        completed: true,
        createDate: null,
        completedDate: null
      };
      const result = { id: '1', ...taskBody };
      mockTasksService.addTask.mockResolvedValue(result);

      expect(await tasksController.addTask(taskBody)).toEqual(result);
      expect(tasksService.addTask).toHaveBeenCalledWith(taskBody);
    });
  });

  describe('updateTask', () => {
    it('should call TasksService.updateTask and return its result', async () => {
      const updateTaskBody: UpdateTaskDto = {
        title: 'Test Task', 
        description: 'Test Description',
        completed: true,
        createDate: null,
        completedDate: null
      };
      const id = '1';
      const result = { id, ...updateTaskBody };
      mockTasksService.updateTask.mockResolvedValue(result);

      expect(await tasksController.updateTask(updateTaskBody, id)).toEqual(result);
      expect(tasksService.updateTask).toHaveBeenCalledWith(updateTaskBody, id);
    });
  });

  describe('getTask', () => {
    it('should call TasksService.getTask and return its result', async () => {
      const id = '1';
      const result = { id, title: 'Test Task', description: 'Test Description' };
      mockTasksService.getTask.mockResolvedValue(result);

      expect(await tasksController.getTask(id)).toEqual(result);
      expect(tasksService.getTask).toHaveBeenCalledWith(id);
    });
  });

  describe('getTaskList', () => {
    it('should call TasksService.getTasks and return its result', async () => {
      const result = [
        { id: '1', title: 'Test Task 1', description: 'Description 1' },
        { id: '2', title: 'Test Task 2', description: 'Description 2' },
      ];
      mockTasksService.getTasks.mockResolvedValue(result);

      expect(await tasksController.getTaskList()).toEqual(result);
      expect(tasksService.getTasks).toHaveBeenCalled();
    });
  });

  describe('deleteTask', () => {
    it('should call TasksService.deleteTask and return its result', async () => {
      const id = '1';
      const result = { success: true };
      mockTasksService.deleteTask.mockResolvedValue(result);

      expect(await tasksController.deleteTask(id)).toEqual(result);
      expect(tasksService.deleteTask).toHaveBeenCalledWith(id);
    });
  });
});
