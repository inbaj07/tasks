import { Injectable } from '@nestjs/common';
import { TaskDto } from 'src/dto/create.task.dto';
import { UpdateTaskDto } from 'src/dto/update.task.dto';

@Injectable()
export class TasksService {
    private tasks = [];

    async addTask(data: TaskDto): Promise<object> {
        this.tasks.push(data)
        return this.tasks;
    }

    async updateTask(data: UpdateTaskDto, id: string): Promise<object> {
        console.log(data,id)
        const task = this.tasks.find(ele => ele.id === id);
        if (task) {
            Object.assign(task, data);
            return task;
        }
        return null;
    }

    async getTask(id: string): Promise<object> {
        return this.tasks.find(ele=> ele.id === id);
    }

    async getTasks(): Promise<object> {
        return this.tasks;
    }

    async deleteTask(id: string): Promise<object> {
        const index = this.tasks.findIndex(ele => ele.id === id);
        if (index > -1) {
            const deletedUser = this.tasks.splice(index, 1);
            return deletedUser[0];
        }
        return null;
    }
    
}
