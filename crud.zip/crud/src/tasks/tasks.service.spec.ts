import { TasksService } from './tasks.service';
import { TaskDto } from 'src/dto/create.task.dto';
import { UpdateTaskDto } from 'src/dto/update.task.dto';

describe('TasksService', () => {
  let tasksService: TasksService;

  beforeEach(() => {
    tasksService = new TasksService();
  });

  it('should add a task', async () => {
    const task: TaskDto = {
      id: '1', title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    const result = await tasksService.addTask(task);
    expect(result).toContainEqual(task);
  });

  it('should get a specific task by ID', async () => {
    const task: TaskDto = {
      id: '1', title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    await tasksService.addTask(task);
    const fetchedTask = await tasksService.getTask('1');
    expect(fetchedTask).toEqual(task);
  });

  it('should return all tasks', async () => {
    const task1: TaskDto = {
      id: '1', title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    const task2: TaskDto = {
      id: '2', title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    await tasksService.addTask(task1);
    await tasksService.addTask(task2);

    const tasks = await tasksService.getTasks();
    expect(tasks).toEqual([task1, task2]);
  });

  it('should update an existing task', async () => {
    const task: TaskDto = {
      id: '1', title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    await tasksService.addTask(task);

    const updatedData: UpdateTaskDto = {
      title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    const updatedTask = await tasksService.updateTask(updatedData, '1');
    expect(updatedTask).toBeDefined();
  });

  it('should return null when updating a non-existent task', async () => {
    const updatedData: UpdateTaskDto = {
      title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    const result = await tasksService.updateTask(updatedData, '999');
    expect(result).toBeNull();
  });

  it('should delete a task', async () => {
    const task: TaskDto = {
      id: '1', title: 'Test Task', 
      description: 'This is a test',
      completed: false,
      createDate: null,
      completedDate: null
    };
    await tasksService.addTask(task);

    const deletedTask = await tasksService.deleteTask('1');
    expect(deletedTask).toEqual(task);

    const tasks = await tasksService.getTasks();
    expect(tasks).toHaveLength(0);
  });

  it('should return null when deleting a non-existent task', async () => {
    const result = await tasksService.deleteTask('999');
    expect(result).toBeNull();
  });
});
